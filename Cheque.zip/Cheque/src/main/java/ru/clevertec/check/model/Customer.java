package main.java.ru.clevertec.check.model;
public class Customer {
    public Customer() {
    }
    private DiscountCard discountCard;
    private double balanceDebitCard;
    public DiscountCard getDiscountCard() {
        return discountCard;
    }
    public void setDiscountCard(DiscountCard discountCard) {
        this.discountCard = discountCard;
    }
    public double getBalanceDebitCard() {
        return balanceDebitCard;
    }
    public void setBalanceDebitCard(double balanceDebitCard) {
        this.balanceDebitCard = balanceDebitCard;
    }
    public Customer(DiscountCard discountCard, double balanceDebitCard) {
        this.discountCard = discountCard;
        this.balanceDebitCard = balanceDebitCard;
    }
    public Customer(double balanceDebitCard) {
        this.balanceDebitCard = balanceDebitCard;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((discountCard == null) ? 0 : discountCard.hashCode());
        long temp;
        temp = Double.doubleToLongBits(balanceDebitCard);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Customer other = (Customer) obj;
        if (discountCard == null) {
            if (other.discountCard != null)
                return false;
        } else if (!discountCard.equals(other.discountCard))
            return false;
        if (Double.doubleToLongBits(balanceDebitCard) != Double.doubleToLongBits(other.balanceDebitCard))
            return false;
        return true;
    }

    // Getters, setters, constructors, etc.
    ////////////////////////////////////////





}