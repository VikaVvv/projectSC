package main.java.ru.clevertec.check.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import main.java.ru.clevertec.check.model.Receipt;

public class ReceiptFormatter {
    public static void writeToCSV(Receipt receipt, String filePath) throws IOException {
        File file = new File(filePath);
        FileWriter writer = new FileWriter(filePath);
        Date data= new Date();
        writer.write(data.toString());
        writer.write(filePath, receipt.getItems(), 0);
        writer.close();
    }
}