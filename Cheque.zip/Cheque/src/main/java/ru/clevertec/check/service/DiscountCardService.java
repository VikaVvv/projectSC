package main.java.ru.clevertec.check.service;

import java.util.Map;

import main.java.ru.clevertec.check.model.DiscountCard;
//import main.java.ru.clevertec.check.util.CSVReader;

public class DiscountCardService {
    private Map<String, DiscountCard> discountCards;

    public DiscountCardService() {
      //  discountCards = CSVReader.readDiscountCards("./src/main/resources/discountCards.csv");
    }

    public DiscountCard getDiscountCard(String number) {
        return discountCards.get(number);
    }
}