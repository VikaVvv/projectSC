package main.java.ru.clevertec.check.service;

import java.util.Map;

import main.java.ru.clevertec.check.model.Product;


public class ProductService {
    private Map<Integer, Product> products;

    // public ProductService() {
       
    // }

    public Product getProduct(int id) {
        return products.get(id);
    }
}