package main.java.ru.clevertec.check.service;

import java.util.Map;

import main.java.ru.clevertec.check.model.Customer;
import main.java.ru.clevertec.check.model.DiscountCard;
import main.java.ru.clevertec.check.model.Product;
import main.java.ru.clevertec.check.model.Receipt;

public class ReceiptService {
    private ProductService productService;
    private DiscountCardService discountCardService;

    public ReceiptService() {
        productService = new ProductService();
        discountCardService = new DiscountCardService();
    }

    public Receipt generateReceipt(Customer customer, Map<Integer, Integer> cart) {
        Receipt receipt = new Receipt();
        double totalPrice = 0.0;
        double discountAmount = 0.0;

        for (Map.Entry<Integer, Integer> entry : cart.entrySet()) {
            int productId = entry.getKey();
            int quantity = entry.getValue();
            Product product = productService.getProduct(productId);
            ReceiptItem item = new ReceiptItem(product, quantity);
            receipt.addItem(item);
            totalPrice += product.getPrice() * quantity;
        }

        if (customer.getDiscountCard() != null) {
            DiscountCard discountCard = discountCardService.getDiscountCard(customer.getDiscountCard().getNumber());
            discountAmount = totalPrice * discountCard.getDiscount();
        }

        double finalPrice = totalPrice - discountAmount;
        receipt.setTotalPrice(totalPrice);
        receipt.setDiscountAmount(discountAmount);
        receipt.setFinalPrice(finalPrice);

        return receipt;
    }
}