package main.java.ru.clevertec.check.model;

public class DiscountCard {
    private String number;
    private double discount;
    public String getNumber() {
        return number;
    }
    public void setNumber(String number) {
        this.number = number;
    }
    public double getDiscount() {
        return discount;
    }
    public void setDiscount(double discount) {
        this.discount = discount;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((number == null) ? 0 : number.hashCode());
        long temp;
        temp = Double.doubleToLongBits(discount);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DiscountCard other = (DiscountCard) obj;
        if (number == null) {
            if (other.number != null)
                return false;
        } else if (!number.equals(other.number))
            return false;
        if (Double.doubleToLongBits(discount) != Double.doubleToLongBits(other.discount))
            return false;
        return true;
    }
    public DiscountCard(String number, double discount) {
        this.number = number;
        this.discount = discount;
    }
    public DiscountCard(String number) {
        this.number = number;
    }
    public DiscountCard() {
    }

    // Getters, setters, constructors, etc.
    ///////////////////////////////////////
}