package main.java.ru.clevertec.check.service;

import main.java.ru.clevertec.check.model.Product;

public class ReceiptItem {

    public ReceiptItem(Product product, int quantity) {
        //TODO Auto-generated constructor stub
    }

}
