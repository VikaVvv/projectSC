package main.java.ru.clevertec.check;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public class CheckRunner {
    public static void main(String[] args) throws IOException 
    {
        Map<Integer, Integer> cart = new HashMap<>();
        String discountCardNumber = null;
        double balanceDebitCard = 0.0;

        readPar(args);
    }

//---------------------------------------------------------------
    public static void readPar(String[] args)
    {
      String[] tmp;
      String id,discountCard,balanceDebitCard,tt;

      for (String arg : args) {

        if(arg.contains("id-"))
          id=arg.substring(3);
        
          if(arg.contains("discountCard="))
          discountCard=arg.substring("discountCard=".length());
          if(arg.contains("balanceDebitCard="))
          {
           balanceDebitCard=arg.substring("balanceDebitCard=".length());
           tt=balanceDebitCard;
          }



      }




    }
}
