package main.java.ru.clevertec.check;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import main.java.ru.clevertec.check.model.Customer;
import main.java.ru.clevertec.check.model.DiscountCard;
import main.java.ru.clevertec.check.model.Receipt;
import main.java.ru.clevertec.check.service.ReceiptService;
import main.java.ru.clevertec.check.util.ReceiptFormatter;

public class CheckRunner {
    public static void main(String[] args) throws IOException {
        Map<Integer, Integer> cart = new HashMap<>();
        String discountCardNumber = null;
        double balanceDebitCard = 0.0;

        for (String arg : args) {
          String[] tmp = arg.split(" ");
          int id= Integer.parseInt(tmp[0]);
          int quantity=Integer.parseInt(tmp[0].substring(2));
          cart.put(id,quantity);

        }
        for (String arg : args) {
            String[] tmp = arg.split("discountCard=");
            String[] tmp1 =tmp[1].split(" ");
            discountCardNumber=tmp1[1];
          }
          for (String arg : args) {
            String[] tmp = arg.split("balanceDebitCard=");
            balanceDebitCard = Double.parseDouble(tmp[1]);
          }
        Customer customer = new Customer();
        customer.setDiscountCard(new DiscountCard(discountCardNumber, 0.0));
        customer.setBalanceDebitCard(balanceDebitCard);

        ReceiptService receiptService = new ReceiptService();
        Receipt receipt = receiptService.generateReceipt(customer, cart);
        ReceiptFormatter.writeToCSV(receipt, "/Users/vvv/Documents/java/Cheque/src/main/java/ru/clevertec/check/result.csv");
    }
}
//.substring(2)
// if (arg.startsWith("id")) {
//     String[] idQuantity = arg.split("-");
//     int id = Integer.parseInt(idQuantity[0]);
//     int quantity = Integer.parseInt(idQuantity[0].substring(2));
//     cart.put(id, quantity);
// }// else if (arg.startsWith("discountCard=")) {
//   //  discountCardNumber = arg.substring(13);
// }// else if (arg.startsWith("balanceDebitCard=")) {
//    // balanceDebitCard = Double.parseDouble(arg.substring(16));
// }