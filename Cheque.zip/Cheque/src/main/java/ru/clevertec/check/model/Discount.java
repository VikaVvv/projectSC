package main.java.ru.clevertec.check.model;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Discount {
    private int id;
    private int number;
    private int DiscountAmount;
    List<List<String>> records = new ArrayList<>();
    public int getId() {
    return id;
}
public void setId(int id) {
    this.id = id;
}
public int getNumber() {
    return number;
}
public void setNumber(int number) {
    this.number = number;
}
public int getDiscountAmount() {
    return DiscountAmount;
}
public void setDiscountAmount(int discountAmount) {
    DiscountAmount = discountAmount;
}
public List<List<String>> getRecords() {
    return records;
}
public void setRecords(List<List<String>> records) {
    this.records = records;
}


  public void ReadDiscount(String filepath)
  {
    Map<Integer, Integer> IndNumb=new HashMap<>();
    Map<Integer, Integer> IndPerc=new HashMap<>();
    
     try  (BufferedReader br= new BufferedReader(new FileReader("src/main/resources/discountCards.csv") ))
       {
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(";");
            Integer index=Integer.parseInt(values[0]);
            Integer number=Integer.parseInt(values[1]);
            Integer percent=Integer.parseInt(values[2]);
            IndNumb.put(index, number);
            IndPerc.put(index,percent);
        }
       }
       catch (IOException e) {
        throw new RuntimeException("Не удалось прочитать файл 'products.csv'", e);
    }
  }
    

   
 

}
