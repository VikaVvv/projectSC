package main.java.ru.clevertec.check.model;

import java.util.List;

public class Receipt {
    private List<ReceiptItem> items;
    private double totalPrice;
    private double discountAmount;
    private double finalPrice;

    // Getters, setters, constructors, etc.
    public int getItems() {
        return items;
    }
    public void setItems(List<ReceiptItem> items) {
        this.items = items;
    }
    public double getTotalPrice() {
        return totalPrice;
    }
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    public double getDiscountAmount() {
        return discountAmount;
    }
    public void setDiscountAmount(double discountAmount) {
        this.discountAmount = discountAmount;
    }
    public double getFinalPrice() {
        return finalPrice;
    }
    public void setFinalPrice(double finalPrice) {
        this.finalPrice = finalPrice;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((items == null) ? 0 : items.hashCode());
        long temp;
        temp = Double.doubleToLongBits(totalPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(discountAmount);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(finalPrice);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Receipt other = (Receipt) obj;
        if (items == null) {
            if (other.items != null)
                return false;
        } else if (!items.equals(other.items))
            return false;
        if (Double.doubleToLongBits(totalPrice) != Double.doubleToLongBits(other.totalPrice))
            return false;
        if (Double.doubleToLongBits(discountAmount) != Double.doubleToLongBits(other.discountAmount))
            return false;
        if (Double.doubleToLongBits(finalPrice) != Double.doubleToLongBits(other.finalPrice))
            return false;
        return true;
    }
    public Receipt(List<ReceiptItem> items, double totalPrice) {
        this.items = items;
        this.totalPrice = totalPrice;
    }
    public Receipt(List<ReceiptItem> items, double totalPrice, double discountAmount) {
        this.items = items;
        this.totalPrice = totalPrice;
        this.discountAmount = discountAmount;
    }
    public Receipt(List<ReceiptItem> items, double totalPrice, double discountAmount, double finalPrice) {
        this.items = items;
        this.totalPrice = totalPrice;
        this.discountAmount = discountAmount;
        this.finalPrice = finalPrice;
    }
    public Receipt() {
        //TODO Auto-generated constructor stub
    }
    public void addItem(main.java.ru.clevertec.check.service.ReceiptItem item) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addItem'");
    }
    
}

class ReceiptItem {
    private Product product;
    private int quantity;
    public Product getProduct() {
        return product;
    }
    public void setProduct(Product product) {
        this.product = product;
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((product == null) ? 0 : product.hashCode());
        result = prime * result + quantity;
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ReceiptItem other = (ReceiptItem) obj;
        if (product == null) {
            if (other.product != null)
                return false;
        } else if (!product.equals(other.product))
            return false;
        if (quantity != other.quantity)
            return false;
        return true;
    }
    public ReceiptItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    // Getters, setters, constructors, etc.
    //////////////////////////////////////
}